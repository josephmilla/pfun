<div class="leftmenu">
	<a href="closure.php">Attribute Closure</a>&nbsp;|&nbsp;
	<a href="fdclosure.php">FD Closure</a>&nbsp;|&nbsp;
	<a href="bcnf.php">BCNF</a>&nbsp;|&nbsp;
	<a href="hash.php">Extensible hash</a>
</div>
<br>